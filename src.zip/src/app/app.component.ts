// src/app/app.component.ts
import { Component, inject } from '@angular/core';
import { RouterModule } from '@angular/router';
import { NewsService } from './services/news.service';

@Component({
  standalone: true,
  selector: 'app-root',
  templateUrl: './app.component.html',
  imports: [RouterModule], // Importa RouterModule para usar router-outlet
  styleUrl: './app.component.scss',
})
export class AppComponent {
  server = inject(NewsService);
}
