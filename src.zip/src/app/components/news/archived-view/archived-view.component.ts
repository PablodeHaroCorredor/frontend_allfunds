import { Component, OnInit, signal, WritableSignal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NewsService } from '../../../services/news.service';
import { News } from '../../../models/news.model'; // Importa el modelo
import { RouterLink } from '@angular/router';

@Component({
  standalone: true,
  selector: 'app-archived-view',
  templateUrl: './archived-view.component.html',
  imports: [CommonModule, RouterLink],
})
export class ArchivedViewComponent implements OnInit {
  archivedNewsList: WritableSignal<News[]> = signal([]); // Usa el tipo News[]

  constructor(private newsService: NewsService) {}

  ngOnInit(): void {
    this.fetchArchivedNews();
  }

  fetchArchivedNews() {
    this.newsService
      .getArchivedNews()
      .subscribe((data: News[]) => this.archivedNewsList.set(data)); // Usa el tipo News[]
  }

  remove(id: string) {
    this.newsService.deleteNews(id).subscribe(() => this.fetchArchivedNews());
  }
}
